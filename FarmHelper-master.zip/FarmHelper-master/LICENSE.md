LICENSE : You can use our code but YOU ARE NOT ALLOWED TO SELL IT OR USE IT IN ANY COMMERCIAL WAY. The copyright belongs to our developers.
